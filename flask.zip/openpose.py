# MPII를 사용한 신체부위 검출
import cv2
import os
import ast
import math
import numpy as np
import json

# MPII에서 각 파트 번호, 선으로 연결될 POSE_PAIRS
HAND_PARTS = {"A": 0, "B": 1, "C": 2, "D": 3, "E": 4,
              "F": 5, "G": 6, "H": 7, "I": 8, "J": 9,
              "K": 10, "L": 11, "N": 12, "M": 13, "O": 14,
              "P": 15, "Q": 16, "R": 17, "S": 18, "T": 19, "U": 20}

HAND_PAIRS = [["A", "B"], ["B", "C"], ["C", "D"], ["D", "E"],
              ["F", "G"], ["G", "H"], ["H", "I"],
              ["J", "K"], ["K", "L"], ["L", "N"],
              ["M", "O"], ["O", "P"], ["P", "Q"],
              ["R", "S"], ["S", "T"], ["T", "U"],
              ["A", "F"], ["A", "J"], ["A", "M"], ["A", "R"]]


def imgkeypoints(inputi):
    inWidth = 368
    inHeight = 368

    # 각 파일 path
    protoFile = "C:/Users/User/Desktop/kwon_caffe_openpose/pose_deploy.prototxt"
    weightsFile = "C:/Users/User/Desktop/kwon_caffe_openpose/pose_iter_102000.caffemodel"

    # 위의 path에 있는 network 불러오기
    net = cv2.dnn.readNetFromCaffe(protoFile, weightsFile)

    # 이미지 읽어오기
    FILE_PATH = inputi
    image = cv2.imread(FILE_PATH)
    src = cv2.imread(FILE_PATH, cv2.IMREAD_GRAYSCALE)

    # frame.shape = 불러온 이미지에서 height, width, color 받아옴
    imageHeight, imageWidth, _ = image.shape

    # network에 넣기위해 전처리
    inpBlob = cv2.dnn.blobFromImage(image, 1.0 / 255, (imageWidth, imageHeight), (0, 0, 0), swapRB=False, crop=False)

    # network에 넣어주기
    net.setInput(inpBlob)

    # 결과 받아오기
    output = net.forward()

    # output.shape[0] = 이미지 ID, [1] =  출력 맵의 높이, [2] = 너비
    H = output.shape[2]
    W = output.shape[3]
    print("이미지 ID : ", len(output[0]), ", H : ", output.shape[2], ", W : ", output.shape[3])  # 이미지 ID

    # 키포인트 검출시 이미지에 그려줌
    # 1~4 엄지, 5~8 검지, 9~12 중지, 13~16 소지, 17~20 약지
    points = []

    for i in range(len(HAND_PARTS)):
        # 해당 신체부위 신뢰도 얻음.
        probMap = output[0, i, :, :]
        # global 최대값 찾기
        minVal, prob, minLoc, point = cv2.minMaxLoc(probMap)
        # 원래 이미지에 맞게 점 위치 변경
        x = (imageWidth * point[0]) / W
        y = (imageHeight * point[1]) / H
        # 키포인트 검출한 결과가 0.1보다 크면(검출한곳이 위 BODY_PARTS랑 맞는 부위면) points에 추가, 검출했는데 부위가 없으면 None으로
        if prob > 0.1:
            points.append((int(x), int(y)))
        else:
            points.append(None)

    # 검지 연결
    for pair in HAND_PAIRS:
        partA = pair[0]
        partA = HAND_PARTS[partA]
        partB = pair[1]
        partB = HAND_PARTS[partB]
        if points[partA] and points[partB]:
            cv2.line(image, points[partA], points[partB], (0, 255, 0), 2)

    #t, _ = net.getPerfProfile()
    #freq = cv2.getTickFrequency() / 1000
    #cv2.putText(output, '%.2fms' % (t / freq), (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0))
    #cv2.imshow('OpenPose using OpenCV', output)
    output = cv2.resize(image, (960, 800))
    cv2.imwrite(inputi.replace(".jpg", "o.jpg").replace(".jpeg", "o.jpeg"), image)
