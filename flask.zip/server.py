# -*- coding: utf-8 -*-
from flask import Flask, render_template, request
import os
from openpose import *
from PIL import Image
import cv2

app = Flask(__name__)
UPLOAD_FOLDER = './static/image'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template('index.html')


@app.route("/success", methods=['GET', 'POST'])
def upload_file():
    content = request.files['file']
    content.save(os.path.join(app.config['UPLOAD_FOLDER'], content.filename))
    imgkeypoints('./static/image/' + content.filename)
    return render_template('success.html', filename1=content.filename,
                           filename2=content.filename.replace(".jpg", "o.jpg").replace(".jpeg", "o.jpeg"))


@app.route('/display/<filename>')
def display_image(filename):
	print('display_image filename: ' + filename)
	return redirect(url_for('static', filename='image/' + filename), code=301)

if __name__ == '__main__':
    app.run(debug=True)
